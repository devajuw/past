result = (5/4)*7*6^2 + (3^(7/9))^3 - 652;
disp(result)