A = [1 2; 3 4]; % example matrix A
B = [5 6; 7 8]; % example matrix B
C = [9 10; 11 12]; % example matrix C

result1 = A*(B+C);
result2 = A*B + A*C;

disp(result1)
disp(result2)

