x = 2;
x = x + 3;
disp(x)
result1 = x + 1*2;
result2 = (x+1)*2;
disp(result1)
disp(result2)

theta = 45;
theta = (theta/180)*pi; % convert to radians
sin_theta = sin(theta);
cos_theta = cos(theta);

result = sin_theta^2 + cos_theta^2;

disp(result)

