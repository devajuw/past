% Odd between 1 to 100 %
sum = 0;
for k = 1:2:100
    k
    sum = sum + k
end
sum;
