x = [0:0.1:20];
y = sin(x);
plot(x,y)