% Array & For Loop %

b1 = [ 3 5 6 9 10]
sum=0;
for k = 1 : 4
    sum = sum + b1(k);
end