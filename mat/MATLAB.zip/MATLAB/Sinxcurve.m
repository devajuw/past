%Making a Plot of Sin X curve

x = [0:0.5:10]
y = tan(x)
plot(x,y)

