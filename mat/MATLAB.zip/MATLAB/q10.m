A = [1 1 2; 1 4 5; 2 5 2];
A_transpose = A';
disp(A_transpose);

B = [3 2; 1 1];
B_transpose = transpose(B);
disp(B_transpose);
