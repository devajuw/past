t= 5;
log(2 + t + t.^2)
exp(t) * (1 + cos(3*t))
cos(t).^2 + sin(t).^2
atan(t)
cot(t) = 1/tan(t)
sec(t).^2 + cot(t) - 1



