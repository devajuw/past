for i = 1:10000
if mod(i, 37) == 0
disp(i)
end
end