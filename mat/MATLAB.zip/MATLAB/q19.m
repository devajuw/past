function result = multiply_numbers(a, b)
    result = a*b;
a = 5;
b = 6;
result = multiply_numbers(a, b);
disp(result)

end
