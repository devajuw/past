result = ((3^7 * log(76)) / (7^3) - 546) + nthroot(910,3);
disp(result);

