result = cos(5*pi/6)^2 * (sin(7*pi/8))^2 + tan(pi/6) * log(8) / 7^(1/2);
result
