% Write a program to find the solution of system of equations using matrix inversion methods %

A = [ 4 1 2; 0 3 1; 0 1 2]
B= [17; 19 ;13]
x = inv(A)*B
