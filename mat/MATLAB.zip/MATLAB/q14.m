sum = 0;
for i = 1:9
sum = sum + i;
end
disp(sum)
