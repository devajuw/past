a = input('Enter first number: ');
b = input('Enter second number: ');
c = input('Enter third number: ');

if (a > b) && (a > c)
    disp(a)
elseif (b > a) && (b > c)
    disp(b)
else
    disp(c)
end
