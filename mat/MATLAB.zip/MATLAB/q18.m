r = (3*350/(4*pi))^(1/3);
surface_area = 4*pi*r^2;
disp(surface_area)
